
function toggleMenu(){
  const nav = document.querySelector('.nav');
  if(!nav) return;
  nav.style.display = (nav.style.display === 'flex') ? 'none' : 'flex';
}

function filterArchive(){
  const y = document.getElementById('yearFilter').value;
  const c = document.getElementById('catFilter').value;
  const d = document.getElementById('dropFilter').value;
  document.querySelectorAll('#archiveGrid .arch').forEach(card=>{
    const show = (!y || card.dataset.year===y) &&
                 (!c || card.dataset.cat===c) &&
                 (!d || card.dataset.drop===d);
    card.style.display = show ? '' : 'none';
  });
}
